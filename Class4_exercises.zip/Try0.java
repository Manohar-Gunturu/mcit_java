
public class Try0 {

	/*Every class in Java is directly or indirectly derived from the Object class. 
	 * If a Class does not extend any other class then it is direct child class 
	 * of Object and if extends other class then it is an indirectly derived 
	 */
	public static void main(String[] args) {
		Object o = new Student(5);
		//type casting
		Student s = (Student)o;
	}

}
class Student{
	int age = 0;
	Student(int age){
		this.age = age;
	}
}