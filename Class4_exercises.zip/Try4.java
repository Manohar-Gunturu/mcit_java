import java.util.Arrays;
import java.util.Comparator;

public class Try4 {

	public static void main(String[] args) {
		
		  Integer x = 5;
	      
	      System.out.println(x.compareTo(3));
	      System.out.println(x.compareTo(5));
	      System.out.println(x.compareTo(8));
	      
	      Employee e1 = new Employee(300, "Jhon");
	      Employee e2 = new Employee(403, "Bob");
	      Employee e3 = new Employee(201,"Ram");
	      Employee[] es = new Employee[3];
	      es[0] = e1;
	      es[1] = e2;
	      es[2] = e3;
	      Arrays.sort(es);
	      for(Employee e : es) {
	    	  System.out.println(e.name);
	      }

	}

}
//do not make this class public, as file should have only one public class file
//comparable goes with natural ordering of the elements
class Employee implements Comparable<Employee>{

	Integer salary; String name;
	Employee(int salary, String name){
		this.salary = salary;
		this.name = name;
	}
	
	@Override
	public int compareTo(Employee o) {
		return (this.salary).compareTo(o.salary);
	}
	
}
