import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Try2 {

	public static void main(String[] args) {
		
		// How arraylist and linkedlist belong to same type List
		//go to http://developer.classpath.org/doc/java/util/ArrayList-source.html
		//and understand how arraylist works
        List<String> e = new ArrayList<String>();
        
        e.add("Java");
        e.add("Python");
        e.add("JS");
        e.add("GO");
        
        for(String s: e) {
        	if(s.equals("GO")) {
        		//e.remove(s); //error as we cannot remove as we read
        	}
        	System.out.println(s);
        }
        
        for(int i = 0 ; i< e.size(); i++) {
        	if(e.get(i).equals("JS")) {
        		//e.remove("JS"); 
        		//removes the element, which also means it decreases the size
        	}
        	System.out.println(e.get(i));
        }
        
        int size = e.size();
        /* identify error in below code +5 marks*/
        for(int i = 0 ; i< size; i++) {
        	if(e.get(i).equals("JS")) {
        		e.remove("JS"); 
        		//removes the element, which also means it decreases the size
        	}
        	System.out.println(e.get(i));
        }
        
        //http://developer.classpath.org/doc/java/util/LinkedList-source.html
        LinkedList<String> h = new LinkedList<String>();
        //same as arraylist but different implementation
	}

}
