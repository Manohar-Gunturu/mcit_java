import java.util.Arrays;
import java.util.Comparator;

public class Try5 {

	public static void main(String[] args) {
          Integer x = 5;
	      
	      System.out.println(x.compareTo(3));
	      System.out.println(x.compareTo(5));
	      System.out.println(x.compareTo(8));
	      
	      Employee e1 = new Employee(300, "Jhon");
	      Employee e2 = new Employee(403, "Bob");
	      Employee e3 = new Employee(201,"Ram");
	      Employee[] es = new Employee[3];
	      es[0] = e1;
	      es[1] = e2;
	      es[2] = e3;
	      //custom sorting, without using natural sorting defined by class
	      Arrays.sort(es,new NameComparator());
	      for(Employee e : es) {
	    	  System.out.println(e.name);
	      }

	}

}

class NameComparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Employee e1 = (Employee) o1;
		Employee e2 = (Employee) o2;
		return e1.name.compareTo(e2.name);
	}
	
	
}
