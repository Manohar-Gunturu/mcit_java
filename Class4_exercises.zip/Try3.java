import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Try3 {

	public static void main(String[] args) {
		//use iterators always
		ArrayList<String> javaRadarList = new ArrayList<String>();
        //Add elements to ArrayList
        
		javaRadarList.add("Java");
		javaRadarList.add("EJB");
		javaRadarList.add("Spring");
        javaRadarList.add("Hibernate");
        
        System.out.println(javaRadarList.contains("Flask"));
        
        //sorts the list
        //ascending order
        Collections.sort(javaRadarList);
        //descending order
        Collections.sort(javaRadarList ,  Collections.reverseOrder());
        
        System.out.println("Original list:" +javaRadarList);
       
        Iterator<String> itr = javaRadarList.iterator();
        while(itr.hasNext()){
              String token = itr.next();
              System.out.println(token);
              //itr.remove(); delete the element safely
        }

	}

}
