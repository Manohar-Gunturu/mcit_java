import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Try8 {

	public static void main(String[] args) {
		//wont works one it return list
		//as we dont know whether array has all unique elements or not
		//Set<Integer> l = Arrays.asList(new Integer[] {1, 3, 2, 4, 8, 9});
        
		
		HashSet<Integer> a = new HashSet<Integer>(); 
		a.add(3); a.add(1); a.add(4); 
		
		HashSet<Integer> a1 = new HashSet<Integer>(); 
		a1.add(3); a1.add(0); a1.add(4); 
		
	    //a1.addAll(a); //union of set a and a1
	    
	    // to find intersection
	    a1.retainAll(a);
	    for(Integer i : a1) {
	    	System.out.println(i);
	    }
	    
	    //difference between sets
	    a1.removeAll(a); 
		
	}

}
