

public class Try {

	//demo on arraycopy(Object src, int srcPos, Object dest, int destPos, int length)

	public static void main(String[] args) {
		  int arr1[] = { 0, 1, 2, 3, 4, 5 };
	      int arr2[] = { 5, 10, 20, 30, 40, 50 };
	      System.arraycopy(arr1, 0, arr2, 0, 1);
	      System.out.print("array2 = ");
	      System.out.print(arr2[0] + " ");
	      System.out.print(arr2[1] + " ");
	      System.out.print(arr2[2] + " ");
	      System.out.print(arr2[3] + " ");
	      System.out.print(arr2[4] + " ");
	      //Similarly we can do that for array of objects
	      //Person[] source = new Person[5]; 
		  //Person[] destination = new Person[9];
          //?
	}

}
class Person{
	int age = 0;
	Person(int age){
		this.age = age;
	}
}