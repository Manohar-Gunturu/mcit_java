import java.util.HashSet;

public class Try6 {

	public static void main(String[] args) {
		//overrides the duplicate values, and no order is followed as in arraylist
		//in arraylist to get the elements in the order you insert them
		//but this is not true with Hashset
		HashSet<String> h = new HashSet<String>();
		// Adding elements into HashSet using add() 
        h.add("Bob"); 
        h.add("Jhon"); 
        h.add("Virat"); 
        h.add("Bob"); // bob is added twice they have same hashvalue so override
        /*
         * surprise is hashset uses hashmap internally
         * http://developer.classpath.org/doc/java/util/HashMap-source.html 
         */
       for(String s: h) {
    	   System.out.println(s);
       }
	}

}
