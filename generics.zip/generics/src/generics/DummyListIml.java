package generics;

public class DummyListIml {

	public static void main(String[] args) {
		
		DummtList<Integer> list = new DummtList<Integer>(4);
		list.add(324);
		list.add(325);
		list.add(326);
		list.add(327);
		list.add(328);
		System.out.println(list.get(3));
	}

}
