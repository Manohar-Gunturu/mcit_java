package generics;

public class DummtList <T>{
    
	T [] container;
	int size;
	int pointer = 0;
	DummtList(int size){
		this.size = size;
		container = (T[]) new Object[size];
	}
	
	void add(T ele){
		 if(pointer >= size){
			 size = size * 2;
			 T [] container1 = (T[]) new Object[size];
			  System.arraycopy(container, 0, container1, 0, container.length); 
			  container = container1;
		 }
		 container[pointer++] = ele; 
	}
	
	T get(int index){
		return container[index];
	}
	
	
	
	
}
