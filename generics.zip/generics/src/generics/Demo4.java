package generics;

import java.util.ArrayList;
import java.util.HashMap;

public class Demo4 {

	public static void main(String[] args) {
		//can be substituted
		HashMap<Integer, ArrayList<String>> nm = new HashMap<>();
		HashMap<Integer, Box1<String>> boxes = new HashMap<>();
        
	}

}
