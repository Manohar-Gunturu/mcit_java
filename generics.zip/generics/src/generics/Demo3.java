package generics;

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Pair<String, Integer> p1 = new Pair<String, Integer>("Even", 8);
	    //or
	    //Pair<String, Integer> p1 = new Pair<>("Even", 8);

	}

}
//multiple type parameter
 class Pair<K, V>  {

    private K key;
    private V value;

    public Pair(K key, V value) {
	this.key = key;
	this.value = value;
    }

    public K getKey()	{ return key; }
    public V getValue() { return value; }
}