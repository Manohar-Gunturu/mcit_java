package generics;

public class Demo2 {

	public static void main(String[] args) {
		   //type is passed as parameter
		   Box1<Integer> b = new Box1<>();
           b.set(new Integer(9));
           //no conversion is needed
           Integer in = b.get();
	}

}

//more generalized box can store any type
class Box1<T> {
    // T stands for "Type"
    private T t;

    public void set(T t) { this.t = t; }
    public T get() { return t; }
}