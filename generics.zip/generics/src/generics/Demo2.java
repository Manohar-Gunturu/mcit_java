package generics;

public class Demo2 {

	public static void main(String[] args) {
		   //type is passed as parameter
		   Box1<Integer> b = new Box1<>();
           b.set(new Integer(9));
           //no conversion is needed
           Integer in = b.get();
           System.out.println(in);
           
           Box1<String> b2 = new Box1<>();
           b2.set("dsgdsg");
           //no conversion is needed
           String s = b2.get();
           System.out.println(s);
	}

}

//more generalized box can store any type
class Box1<T> {
    // T stands for "Type"
    private T t;

    public void set(T t) { this.t = t; }
    public T get() { return t; }
}