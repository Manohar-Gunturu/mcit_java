package generics;

public class Demo1 {

	public static void main(String[] args) {
		
        Box b = new Box();
        Integer i = new Integer(13);
        b.set(i);
        b.set(new String("sdgdsrg"));
        Integer g = (Integer) b.get();
		
	}

}
//our arraylist is also a box
 class Box {
    private Object object;

    public void set(Object object) { this.object = object; }
    public Object get() { return object; }
}
