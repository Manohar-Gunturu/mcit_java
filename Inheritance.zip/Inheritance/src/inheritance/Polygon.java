
package inheritance;

public class Polygon {
    
   int sides;
   String name;
   Polygon(int sides, String name ){
     this.sides = sides;
     this.name = name;
   } 
   int getSides(){
     return sides;
   }
   String getName(){
     return name;
   }
   
   
}
