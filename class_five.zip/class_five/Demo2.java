package class_five;

public class Demo2 {

	public static void main(String[] args) {
        
		iambadguy();
		
	}

	//works fine why?
	//you are saying this functions throws some error, but no one is throwing error
    //funny right? 
	public static void iambadguy() throws BadHappend1{
		
                  
	}

}

class BadHappend1 extends RuntimeException{
	   
	BadHappend1(){

	}
	
	public String toString() {
		return "Bad happend please stop";
		
	}
	
}