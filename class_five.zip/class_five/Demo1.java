package class_five;

public class Demo1 {

	//this is compile time error
	public static void main(String[] args) {
		iambadguy();	
	}
	
	public static void iambadguy() throws BadHappend{
                  
	}

}

class BadHappend extends Exception{
	   
	BadHappend(){
		
	}
	
	public String toString() {
		return "Bad happend please stop";
		
	}
	
}