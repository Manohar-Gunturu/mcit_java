package class_five;

public class Demo3 {

	public static void main(String[] args) {
        
		iambadguy();
		
	}
	
	public static void iambadguy() throws BadHappend1{
		
		throw new BadHappend1();
                  
	}

}

