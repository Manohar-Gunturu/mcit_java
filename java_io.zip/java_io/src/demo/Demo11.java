package demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Demo11 {

	public static void main(String[] args) {
		//demo 1
		Stream.of(2, 3, 6)
	    .findFirst()
	    .ifPresent(System.out::println); 

		//demo 2
		List<Integer> nums = new ArrayList<Integer>();
		nums.add(2);
		nums.add(3);
		nums.add(6);
	    nums.stream().map(n -> { 
	    	if (n > 2 ){ return n + 2; } else { return n; } 
	    	}
	    )
	    .forEach(System.out::println); 
	    
	    
	    //demo 3
	    nums.stream().map(n -> 2 * n + 1).mapToInt(n -> n)
	    .average()
	    .ifPresent(System.out::println);
	    
	    
	    //demo 4
	    nums.parallelStream().forEach(System.out::println);

		
	}

}
