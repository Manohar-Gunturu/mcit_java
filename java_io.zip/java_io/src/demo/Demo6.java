package demo;

import java.io.File;

public class Demo6 {

	public static void main(String[] args) {
		
		File f = new File("out.txt"); 
		  
        System.out.println("File name :"+f.getName()); 
        System.out.println("Absolute path:" +f.getAbsolutePath()); 
        System.out.println("Exists :"+f.exists()); 
        if(f.exists()) 
        { 
            System.out.println("Is a directory:"+f.isDirectory()); 
            System.out.println("File Size in bytes "+f.length()); 
        } 

	}

}
