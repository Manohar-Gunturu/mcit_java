package demo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Demo9 {
   
	
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		ServerSocket ss = new ServerSocket(8070);
		while(true){		
			new Handler(ss.accept()).start();
		}
	}
	
}

class DataAccess{
	static int y = 9;
}


class Handler extends Thread{
    
	Socket socket;
	Handler(Socket s){
		this.socket = s;	
		int g = DataAccess.y;
	}
	
	public void run(){
		InputStream in = null;
		OutputStream out = null;
		try {
			in = socket.getInputStream();
		
		out = socket.getOutputStream();
		int line;
		System.out.println("ready");
		while ((line = in.read()) != -1) {
			System.out.print((char)line);
			if(line == 13 && in.read() == 10 )
				break;
		}
        //i am calling a method x , method x takes 1 hour to respond back
		Thread.sleep(90000);
		String httpHeader = "HTTP/1.0 200 OK\r\n";
		
		out.write(httpHeader.getBytes());	
		out.write("\r\n".getBytes());
	    out.write("Hello".getBytes());
		out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
				in.close();
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	
	
}




