package demo;

import java.io.File;

public class Demo7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("C:\\Users\\st294_1018\\workspace1\\java_io");
        String folder[]=f.list();
        
        //can you modify it to check it is a file or folder
        //and check extension with endsWith
        for(String name: folder) {
        	
        	if(name.endsWith("txt")){
        		 System.out.println(name);
        	}
        }


	}

}
