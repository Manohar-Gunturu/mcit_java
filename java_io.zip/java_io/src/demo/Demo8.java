package demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Demo8 {

	public static void main(String[] args) throws IOException {
		
		ServerSocket ss = new ServerSocket(8090);
		
		Socket s = ss.accept();
		System.out.println("Accepted a message");
		InputStream in = s.getInputStream();

		int line;
		while ((line = in.read()) != -1) {
			System.out.print((char)line);
		}

		
	}

}
