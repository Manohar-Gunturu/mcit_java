package demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Demo5 {

	public static void main(String[] args) {
		
		Student s = null;
		 try
	        {    
	            // Reading the object from a file 
	            FileInputStream file = new FileInputStream("obj.txt"); 
	            ObjectInputStream in = new ObjectInputStream(file); 
	              
	            // Method for deserialization of object 
	            s = (Student)in.readObject(); 
	              
	            in.close(); 
	            file.close(); 
	              
	            System.out.println("Object has been deserialized "); 
	            System.out.println("name = " + s.name); 
	            System.out.println("marks = " + s.marks[1]); 
	        }	          
	        catch(IOException ex) 
	        { 
	            System.out.println("IOException is caught"); 
	        }       
	        catch(ClassNotFoundException ex) 
	        { 
	            System.out.println("ClassNotFoundException is caught"); 
	        } 

	}

}
