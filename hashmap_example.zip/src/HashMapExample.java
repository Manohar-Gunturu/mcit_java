import java.util.HashMap;


public class HashMapExample {

	public static void main(String[] args) {
		//< key, value >
		HashMap<Integer, Student> index = new HashMap();
		Student s1 = new Student(2, "Jhon");
		Student s2 = new Student(1, "Bob");
		Student s3 = new Student(4, "ABC");
		Student s4 = new Student(3, "Shan");
		//put(key, value)
		index.put(2, s1);
		index.put(1, s2);
		index.put(4, s3);
		index.put(3, s4);
		
		//get method takes get(key)
		Student sr4 = index.get(1);
		
	}

}
