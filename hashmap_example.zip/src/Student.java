
public class Student {
   int id;
   String name;
   Student(int id, String name){
	   this.id = id;
	   this.name = name;
   }
   
   int getID(){
	   return this.id;
   }
   
   String getName(){
	   return this.name;
   }
   
}
