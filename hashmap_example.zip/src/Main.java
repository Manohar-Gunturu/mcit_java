import java.util.ArrayList;


public class Main {

	public static void main(String[] args) {
		

		ArrayList<Student> st_list = new ArrayList(25); 
        
		Student s1 = new Student(2, "Jhon");

		st_list.add(s1);
		Student s2 = new Student(1, "Bob");
		Student s3 = new Student(4, "ABC");
		Student s4 = new Student(3, "Shan");
		st_list.add(s2); st_list.add(s3); st_list.add(s4);
		
		//complexity is O(n)
		for(int i=0;i<st_list.size(); i = i + 1){
			 Student tmp = st_list.get(i); 
			 if(tmp.getID() == 4){
				 System.out.println(tmp.getName());
			 }			
		}
		
		
	}

}
