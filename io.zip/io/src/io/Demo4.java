package io;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

class Student implements java.io.Serializable 
{ 
    public int id; 
    public String name; 
    public int[] marks = {  24, 45,60 };
  
    // Default constructor 
    public Student(int id, String name) 
    { 
        this.id = id; 
        this.name = name; 
    } 
  
} 

public class Demo4 {

	public static void main(String[] args) {

		Student s = new Student(1,"Jhon");
		// Serialization  
        try
        {    
            //Saving of object in a file
        	//why not filewriter?
            FileOutputStream file = new FileOutputStream("obj.txt"); 
            ObjectOutputStream out = new ObjectOutputStream(file); 
              
            // Method for serialization of object 
            out.writeObject(s); 
              
            out.close(); 
            file.close(); 
              
            System.out.println("Object has been serialized"); 
  
        }
        catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
		
	}

}
