package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Demo1 {

	//Java IO streams are flows of data you can either read from, or write to. 
	// streams are typically connected to a data source, or data destination, 
	// like a file, network connection etc.
	public static void main(String[] args) throws IOException {
		
		FileInputStream in = null;
        FileOutputStream out = null;

        try {
            in = new FileInputStream("input.txt");
            out = new FileOutputStream("out.txt");
            int c;
            //Disadvantage: 
            // CopyBytes spends most of its time in a simple loop that reads the
            //input stream and writes the output stream, one byte at a time
            while ((c = in.read()) != -1) {
            	System.out.println(c);
            	System.out.write(c);
                out.write(c);
            }
        } finally {
        	//close the streams always
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }

	}

}
