package io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Demo9 {

	public static void main(String[] args) throws IOException {
		
		ServerSocket ss = new ServerSocket(8070);
		
				
		Socket s = ss.accept();
		BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8" ));
		OutputStream out = s.getOutputStream();
		String line;
		System.out.println("ready");
		while ((line = in.readLine()) != null) {
			System.out.println(line);
			if(line.isEmpty())
				break;
		}
        System.out.println("Done sending");
		String httpHeader = "HTTP/1.0 200 OK\r\n";
		out.write(httpHeader.getBytes());	
		out.write("\r\n".getBytes());
	    out.write("Hello".getBytes());
		out.flush();
		out.close();
		s.close();
		}
	
	}



