package javaapplication3;
public class InterfaceExample {

    public static void main(String[] args) {
       
        CarInterface ci = new SpeedCar(2,20);
        CarInterface ci1 = new MountainCar(3, 33);
        carInt(new SpeedCar(3,33)); 
    }
    
    public static void carInt(CarInterface ci){
        System.out.println(ci.getSeats());
    }
}
