package javaapplication3;

/**
 *
 * @author st294_1018
 */
public class Student implements StudentRules,CarInterface{
    static int pass_mark = 60;
    int id;
    int age;
    int marks;
    static String college = "MCIT";
    Student(int id, int age, int marks){
      this.id = id;
      this.age = age;
      this.marks = marks;
    }
    
    int getMarks(){
        System.out.println("Object pointer is ");
        System.out.println(this);
       return marks;
    }
    
    static double addMarks(){
       //some logic go here
       return 1.23;
    }

    @Override
    public String getCourse() {
       return "JAVAFS";
    }

    @Override
    public int getID() {
        return id;
    }

    @Override
    public int getSeats() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getSpeed() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
