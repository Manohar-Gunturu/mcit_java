/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

/**
 *
 * @author st294_1018
 */
public class Marks {
    
    private int mark = 0;
    int student_id = 0;
    Marks(int student_id, int mark){
      this.mark = mark;
      this.student_id = student_id;
    }  
    
    public int getMark(){
       return mark;
    }
    
}
